if(window.sessionStorage.logged == 'true'){
}
else {
  window.location.href = "login.html";
}
